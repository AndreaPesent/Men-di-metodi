import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int risposta = 0;
        String nome = "";
        String cancellanome = "";
        String cercanome="";
        System.out.println("SCEGLI UNA DELLE SEGUENTI OPZIONI");
        System.out.println("1-Aggiunta di un nome");
        System.out.println("2-Cancellazione del singolo nome");
        System.out.println("3-Ricerca sequenziale di un nome");
        System.out.println("4-Visualizza nomi ripetuti con numero ripetizioni");
        System.out.println("5-Modifica di un nome");
        System.out.println("6-Visualizzazione di tutti i nomi presenti");
        System.out.println("7-Ricerca del nome più lungo e più corto");
        System.out.println("8-Cancellazione di tutte le occorrenze di un nome");
        System.out.println("0-Uscita");
        risposta = in.nextInt();
        switch (risposta) {
            case 1:
                System.out.println("Scrivi il nome da inserire");
                nome = in.nextLine();
            case 2:
                System.out.println("Scrivi il nome da cancellare");
                cancellanome = in.nextLine();
            case 3:
                System.out.println("Quale nome vuoi cercare?");
                cercanome=in.nextLine();
            case 4:
                System.out.println();
            case 5:
            case 6:
            case 7:
            case 8:
            case 0:
        }
    }
    private static String Aggiunta(String nome) {
        String[] nomi = new String[100];
        for (int i = 0; i < nomi.length; i++) {
            nomi[i] = nome;
        }
        return nomi[i];
    }
    private static String Cancella(String cancellanome)
    {
        String[] nomi = new String[100];
        for (int i=0;i<nomi.length;i++)
        {
            if (nomi[i]==cancellanome)
            {
                nomi[i-1]=nomi[i];
            }
        }
        return nomi[i];
    }
    private static String Cerca (String cercanome)
    {
        String[] nomi = new String[100];
        int posizione=0;
        for (int i=0;i<nomi.length;i++)
        {
            if (nomi[i]==cercanome)
            {
               posizione=i;
            }
        }
        return posizione;
    }
    private static String Ripetizioni (String nomi)
    {
        for (int i=0;i< nomi.length;i++)
        {

        }
    }

}